﻿using System;

namespace EmmaSpit_DSA_Assign1
{
    class Program
    {
        static void Main(string[] args)
        {
            //ask user to input - save in class/array
            Console.WriteLine("Hello World!");

        }
    }
}
